/* Includes */
#include "apm32f0xx_int.h"

/** @addtogroup Examples
  * @brief ADC_POTENTIOMETER examples
  @{
  */

/** @addtogroup ADC_POTENTIOMETER
  @{
  */

/** @defgroup ADC_POTENTIOMETER_INT_Functions INT_Functions
  @{
  */

/*!
 * @brief        This function handles NMI exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void NMI_Handler(void)
{
}

/*!
 * @brief        This function handles Hard Fault exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void HardFault_Handler(void)
{
}

/*!
 * @brief        This function handles SVCall exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void SVC_Handler(void)
{
}

/*!
 * @brief        This function handles PendSV_Handler exception
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void PendSV_Handler(void)
{
}

/*!
 * @brief        This function handles SysTick Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void SysTick_Handler(void)
{

}

/*!
 * @brief        This function handles TMR14 Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void TMR14_IRQHandler(void)
{
    TMR14_Isr();
}

/*!
 * @brief        This function handles ADC1 interrupt Handler
 *
 * @param        None
 *
 * @retval       None
 *
 * @note
 */
void ADC1_COMP_IRQHandler(void)
{
    ADC1_Isr();
}

/**@} end of group ADC_POTENTIOMETER_INT_Functions */
/**@} end of group ADC_POTENTIOMETER */
/**@} end of group Examples */
